// Provide default empty implementation of user_rf_pre_init
// to maintain compatibility with older SDK versions.
void user_rf_pre_init(void)
{
}
